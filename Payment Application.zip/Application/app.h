#ifndef NK1
#define	NK1
void appStart(void);
#endif // !NK
